class User {
  String id;
  String name;
  String email;
  String phone;

  //construtor
  User(this.id, this.name, this.email, this.phone);

  User.fromJson(Map json)
      : id = json['id'],
        name = json['name'],
        email = json['email'],
        phone = json['phone'];

  Map toJson() {
    return {'id': id, 'name': name, 'email': email, 'phone': phone};
  }
}

class userEXPanel {
  userEXPanel({
    required this.expandedValue,
    required this.headerValue,
    this.isExpanded = false,
  });

  String expandedValue;
  String headerValue;
  bool isExpanded;
}

